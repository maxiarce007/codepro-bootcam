01: 
reglas generales
domina tu pc
proomp ing.
02.
tatattatatat